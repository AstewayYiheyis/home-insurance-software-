﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home_Inventory_App
{
    public partial class HomeInventorySystem : Form
    {
        internal string UserName { get; set; }

        public HomeInventorySystem()
        {
            InitializeComponent();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit!", "Home Inventory System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if(iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string item;
            int amount;
            string description;
            DateTime purchasedDate;
            int cost;
            string brand;

            if((ItemBox.Text == "") || (AmountBox.Text == "") ||  (PurchasedYearBox.Text == "") || (CostBox.Text == "") || (BrandBox.Text == ""))
            {
                MessageBox.Show("Missing a required information!");
            }

            item = ItemBox.Text;
            amount = int.Parse(AmountBox.Text);
            description = DescriptionBox.Text;
            purchasedDate = DateTime.Parse(PurchasedYearBox.Text);
            cost = int.Parse(CostBox.Text);
            brand = BrandBox.Text;
            HomeInventoryDB.AddItem(UserName, item, amount, description, purchasedDate, cost, brand);
            PopulateList();
        }


        private void PopulateList() 
        {
            listView1.Items.Clear();
            List<HomeInventory> homeInventoryList;
            //try
            //{
            homeInventoryList = HomeInventoryDB.GetHomeInventory(UserName);
            if (homeInventoryList.Count > 0)
            {
                HomeInventory homeInventory;
                for (int i = 0; i < homeInventoryList.Count; i++)
                {
                    homeInventory = homeInventoryList[i];
                    ListViewItem item = listView1.Items.Add(homeInventory.Item);
                    item.SubItems.Add(homeInventory.Amount.ToString());
                    item.SubItems.Add(homeInventory.Description);
                    item.SubItems.Add(homeInventory.PurchasedDate.ToString("MM/dd/yyyy"));
                    item.SubItems.Add(homeInventory.Cost.ToString("C"));
                    item.SubItems.Add(homeInventory.Brand);
                }
            }
            //}
            //catch(Exception ex) { MessageBox.Show(ex.Message, ex.GetType().ToString());}
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            PopulateList();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ItemBox.Text = ("");
            AmountBox.Text = ("");
            DescriptionBox.Text = ("");
            PurchasedYearBox.Text = ("");
            CostBox.Text = ("");
            BrandBox.Text = ("");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string item;  
            int amount; 
            string description;
            DateTime purchasedDate; 
            double Cost;
            string brand;
            string username;

            foreach (ListViewItem items in listView1.SelectedItems)
            {
                listView1.Items.Remove(items);
                item = items.Text;
                HomeInventoryDB.DeleteItem(item, UserName);
            }
        }
    }
}
