﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Inventory_App
{
    public class AccountList
    {
        private string userName;
        private string password;
        private string email;

        public AccountList()
        {
           
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value;  }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
    }
}
