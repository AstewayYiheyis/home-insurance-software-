﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;


namespace Home_Inventory_App
{
    class AccountListDB
    {
        public static SqlConnection GetConnection()
        {
            string connStr = "Server=LAPTOP-OKH3LL5O\\SQLEXPRESS;Database=InventoryDatabase;Trusted_Connection=yes;";
            SqlConnection conn = new SqlConnection(connStr);
            return conn;
        }

        public static void AddItem(string username, string password)
        {
            string insStmt = "INSERT INTO ACCOUNTLIST (UserName, Password) VALUES (@username, @password)";
            SqlConnection conn = GetConnection();
            SqlCommand insCmd = new SqlCommand(insStmt, conn);
            insCmd.Parameters.AddWithValue("@username", username);
            insCmd.Parameters.AddWithValue("@password", password);

            conn.Open();
            insCmd.ExecuteNonQuery();
            //catch (SqlException ex) { throw ex; }
            //finally { conn.Close(); }
            conn.Close();
        }

        public static List<HomeInventory> GetAccountList(string username)
        {
            List<HomeInventory> homeInventoryList = new List<HomeInventory>();
            SqlConnection conn = GetConnection();
            string selStmt = "SELECT * FROM AccountList WHERE UserName = @username ORDER BY UserName";
            SqlCommand selCmd = new SqlCommand(selStmt, conn);
            selCmd.Parameters.AddWithValue("@username", username);

            //try
            //{
            conn.Open();
            SqlDataReader reader = selCmd.ExecuteReader();
            while (reader.Read())
            {
                AccountList accountList = new AccountList();
                accountList.UserName = reader["UserName"].ToString();
                accountList.Password = reader["Password"].ToString();
            }
            reader.Close();
            //}
            //catch (SqlException ex) { throw ex; }a
            //finally { conn.Close(); }
            conn.Close();
            return homeInventoryList;
        }
    }
}
