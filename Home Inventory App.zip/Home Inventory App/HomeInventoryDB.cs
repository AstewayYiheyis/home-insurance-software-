﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;


namespace Home_Inventory_App
{
    class HomeInventoryDB
    {
        public static SqlConnection GetConnection()
        {
            string connStr="Server=LAPTOP-OKH3LL5O\\SQLEXPRESS;Database=InventoryDatabase;Trusted_Connection=yes;";
            SqlConnection conn = new SqlConnection(connStr);
            return conn;
        }
        public static void AddItem(string username, string item, int amount, string description, DateTime purchasedDate, int cost, string brand)
        {
            string insStmt = "INSERT INTO INVENTORY (UserName, Item, Amount, Description, PurchasedDate, Cost, Brand) VALUES (@username, @item, @amount, @description, @purchasedDate, @cost, @brand)";
            SqlConnection conn = GetConnection();
            SqlCommand insCmd = new SqlCommand(insStmt, conn);
            insCmd.Parameters.AddWithValue("@username", username);
            insCmd.Parameters.AddWithValue("@item", item);
            insCmd.Parameters.AddWithValue("@amount", amount);
            insCmd.Parameters.AddWithValue("@description", description);
            insCmd.Parameters.AddWithValue("@purchasedDate", purchasedDate);
            insCmd.Parameters.AddWithValue("@cost", cost);
            insCmd.Parameters.AddWithValue("@brand", brand);

            { conn.Open(); insCmd.ExecuteNonQuery(); }
            //catch (SqlException ex) { throw ex; }
            //finally { conn.Close(); }
            conn.Close();
        }

        public static void DeleteItem(string item, string username)
        {
            string insStmt = "DELETE FROM INVENTORY WHERE Item = @item AND Username = @username";
            SqlConnection conn = GetConnection();
            SqlCommand insCmd = new SqlCommand(insStmt, conn);
            insCmd.Parameters.AddWithValue("@username", username);
            insCmd.Parameters.AddWithValue("@item", item);

            { conn.Open(); insCmd.ExecuteNonQuery(); }
            //catch (SqlException ex) { throw ex; }
            //finally { conn.Close(); }
            conn.Close();
        }

        public static List<HomeInventory> GetHomeInventory(string username)
        {
            List<HomeInventory> homeInventoryList = new List<HomeInventory>();
            SqlConnection conn = GetConnection();
            string selStmt = "SELECT * FROM Inventory WHERE UserName = @username ORDER BY Item";
            SqlCommand selCmd = new SqlCommand(selStmt, conn);
            selCmd.Parameters.AddWithValue("@username", username);

            //try
            //{
                conn.Open();
                SqlDataReader reader = selCmd.ExecuteReader();
                while (reader.Read())
                {
                    HomeInventory homeInventory = new HomeInventory();
                    homeInventory.Item = reader["Item"].ToString();
                    homeInventory.Amount = (int)reader["Amount"];
                    homeInventory.Description = reader["Description"].ToString();
                    homeInventory.PurchasedDate = (DateTime)reader["PurchasedDate"];
                    homeInventory.Cost = (int)reader["Cost"];
                    homeInventory.Brand = reader["Brand"].ToString();
                    homeInventoryList.Add(homeInventory);
                }
                reader.Close();
            //}
            //catch (SqlException ex) { throw ex; }
            //finally { conn.Close(); }
            conn.Close();
            return homeInventoryList;
        }
    }
}
