﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Inventory_App
{
    class HomeInventory
    {
        private string item;
        private int amount;
        private string description;
        private DateTime purchasedDate;
        private int cost;
        private string brand;

        public HomeInventory()
        {
        }

        public string Item
        {
            get { return item; }
            set { item = value; }
        }

        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public DateTime PurchasedDate
        {
            get { return purchasedDate; }
            set { purchasedDate = value; }
        }

        public int Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        public string Brand
        {
            get { return brand; }
            set { brand = value; }
        }
    }
}
